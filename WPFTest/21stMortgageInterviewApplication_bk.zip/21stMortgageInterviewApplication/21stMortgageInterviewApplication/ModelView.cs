﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _21stMortgageInterviewApplication
{
    public class ModelView
    {

        List<int> inputNumberList;

        private string _inputString;
        public string TxtInputString { 
            set {
                _inputString = value;
            } 
        }

        private string _operationType;
        public string OperationType { 
            set {
                _operationType = value;
                GetResults();
            } 
        }

        private string _result;
        public string Result { 
            get {

                return _result;
            }
        }

        public string ResultColor { 
            get {
                if (!string.IsNullOrEmpty(_result)) {
                    int _resultNumber = 0;
                    int.TryParse(_result, out _resultNumber);
                    if (_resultNumber > 0)
                        return "Green";
                    else if (_resultNumber < 0)
                        return "Red";
                }
                return "White"; //return white, if it is error or zero
            } 
        }

        private bool GetResults() {
            try
            {
                int sum = 0;
                List<string> inputStringList = _inputString.Split(",").ToList();
                inputNumberList = inputStringList.Select(int.Parse).ToList();
                if (_operationType == "Large" && inputNumberList.Count > 0)
                {
                    _result = inputNumberList[inputNumberList.Count - 1].ToString();
                }
                else if ((_operationType == "Odd" || _operationType == "Even" ) && inputNumberList.Count > 0) {

                    foreach (int number in inputNumberList)
                    {
                        if (number % 2 != 0 && _operationType == "Odd")
                        {
                            sum = sum + number;
                        }
                        else if (number % 2 == 0 && _operationType == "Even")
                        {
                            sum = sum + number;
                        }
                    }
                    _result = sum.ToString();
                }
                return true;
            }
            catch (FormatException)
            {
                _result = "invalid input.";
                return false;
            }
        }
    }
}
