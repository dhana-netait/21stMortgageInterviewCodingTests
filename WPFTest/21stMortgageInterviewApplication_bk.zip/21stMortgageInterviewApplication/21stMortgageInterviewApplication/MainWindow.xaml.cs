﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.Generic;

namespace _21stMortgageInterviewApplication
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<int> inputNumberList;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void txtInput_LostFocus(object sender, RoutedEventArgs e)
        {
            inputNumberList = new List<int>();
            if (txtInput.Text.Length > 0)
            {
                try
                {
                    List<string> inputStringList = txtInput.Text.Split(",").ToList();
                    inputNumberList = inputStringList.Select(int.Parse).ToList();
                    //resetting everytime when input text value changes, if input value list is valid.
                    txtResults.Background = Brushes.White;
                    txtResults.FontWeight = FontWeights.Normal;
                    btnLargeValue.IsEnabled = true;
                    btnSumEven.IsEnabled = true;
                    btnSumOdd.IsEnabled = true;
                    txtResults.Text = string.Empty;
                }
                catch (FormatException)
                {
                    displayResults("invalid input.", "error");
                }
            }
        }

        private void btnLargeValue_click(object sender, RoutedEventArgs e)
        {
            if (inputNumberList != null && inputNumberList.Count > 0)
            {
                inputNumberList.Sort();
                displayResults(inputNumberList[inputNumberList.Count - 1].ToString(), string.Empty);
            }
        }

        private void displayResults(string message, string messageType)
        {
            txtResults.Text = message;
            if (messageType == "error")
            {
                txtResults.Background = Brushes.White;
                txtResults.FontWeight = FontWeights.Bold;
                btnLargeValue.IsEnabled = false;
                btnSumEven.IsEnabled = false;
                btnSumOdd.IsEnabled = false;
            }
            else {
                txtResults.Background = (int.Parse(message)>= 0) ? Brushes.Green : Brushes.Red;
            }
        }

        private void btnSum_Click(object sender, RoutedEventArgs e)
        {
            if (inputNumberList != null && inputNumberList.Count > 0)
            {
                int sum = 0;
                foreach (int number in inputNumberList)
                {
                    if (number % 2 != 0 && ((System.Windows.FrameworkElement)sender).Name == "btnSumOdd")
                    {
                        sum = sum + number;
                    }
                    else if (number % 2 == 0 && ((System.Windows.FrameworkElement)sender).Name == "btnSumEven")
                    {
                        sum = sum + number;
                    }
                }
                displayResults(sum.ToString(), string.Empty);
            }
        }
    }
}
