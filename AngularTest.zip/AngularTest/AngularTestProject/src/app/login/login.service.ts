import { Injectable } from '@angular/core';
import { ILoginResult } from './login-result';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  result!: ILoginResult;
  constructor() {
   }

  checkLogin(username: any, password: any): Promise<ILoginResult> {
    this.result.loginSuccessful = true;
    return Promise.resolve(this.result);
  }
}
